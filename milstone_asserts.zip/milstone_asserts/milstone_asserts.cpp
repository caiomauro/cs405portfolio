// Uncomment the next line to use precompiled headers
// include "pch.h"
// uncomment the next line if you do not use precompiled headers
// #include "../../../../../usr/local/Cellar/googletest/1.15.0/include/gtest/gtest.h"
#include "gtest/gtest.h"
#include <iostream>
#include <memory>
#include <vector>
#include <cassert>
#include <ctime>

// The global test environment setup and tear down
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        // Initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// Create our test class to house shared data between tests
class CollectionTest : public ::testing::Test
{
protected:
    // Create a smart pointer to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    {
        // Create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    {
        // Erase all elements in the collection, if any remain
        collection->clear();
        // Free the pointer
        collection.reset(nullptr);
    }

    // Helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// Test that a collection is empty when created.
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // Is the collection created
    ASSERT_TRUE(collection);

    // If empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // Is the collection empty?
    ASSERT_TRUE(collection->empty());

    // If empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

// AlwaysFail test to demonstrate failure
TEST_F(CollectionTest, AlwaysFail)
{
    FAIL();
}

// Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    ASSERT_EQ(collection->size(), 0);
    add_entries(1);
    ASSERT_EQ(collection->size(), 1);
}

// Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    EXPECT_EQ(collection->size(), 0);
    add_entries(5);
    ASSERT_EQ(collection->size(), 5);
}

// Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxSizeNotLessThanSizeFail)
{
    // This is a negative test where we expect max_size to be less than size, which should fail
    ASSERT_LT(collection->max_size(), collection->size());
}

// Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapacityGreaterThanSize)
{
    ASSERT_GE(collection->capacity(), collection->size());
}

// Create a test to verify resizing increases the collection
TEST_F(CollectionTest, EnsureResizingIncreasesCollection)
{
    const int original_size = collection->size();
    collection->resize(original_size + 1);
    ASSERT_EQ(collection->size(), original_size + 1);
}

// Create a test to verify resizing decreases the collection
TEST_F(CollectionTest, EnsureResizingDecreasesCollection)
{
    collection->resize(5);
    ASSERT_EQ(collection->size(), 5);
    collection->resize(4);
    ASSERT_EQ(collection->size(), 4);
}

// Create a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, EnsureResizeToZero)
{
    collection->resize(5);
    ASSERT_EQ(collection->size(), 5);
    collection->resize(0);
    ASSERT_EQ(collection->size(), 0);
}

// Create a test to verify clear erases the collection
TEST_F(CollectionTest, EnsureClearErases)
{
    add_entries(5);
    ASSERT_EQ(collection->size(), 5);
    collection->clear();
    ASSERT_EQ(collection->size(), 0);
}

// Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, EnsureEraseErases)
{
    add_entries(5);
    ASSERT_EQ(collection->size(), 5);
    collection->erase(collection->begin(), collection->end());
    ASSERT_EQ(collection->size(), 0);
}

// Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, EnsureReserveIncreasesCapacityOnlyFail)
{
    add_entries(5);
    ASSERT_EQ(collection->size(), 5);
    size_t old_capacity = collection->capacity();
    collection->reserve(old_capacity + 10);
    ASSERT_GT(collection->capacity(), old_capacity);
    // This assertion is intentionally wrong to make it a negative test
    ASSERT_EQ(collection->size(), 7);
}

// Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
TEST_F(CollectionTest, ThrowsOutOfRangeWhenAccessingOutOfBounds)
{
    add_entries(1);
    ASSERT_THROW(collection->at(1), std::out_of_range);
}

// Positive test: Verify that the collection can be correctly accessed by index
TEST_F(CollectionTest, CanAccessElementsByIndex)
{
    add_entries(5);
    for (int i = 0; i < 5; ++i)
    {
        ASSERT_NO_THROW(collection->at(i));
    }
}

// Negative test: Verify that accessing an out-of-bounds index throws an exception when the collection is not empty
TEST_F(CollectionTest, ThrowsOutOfRangeWhenAccessingOutOfBoundsInNonEmptyCollection)
{
    add_entries(5);
    ASSERT_THROW(collection->at(5), std::out_of_range);
}

int main(int argc, char** argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    int result = RUN_ALL_TESTS();
    std::cout << "Press enter to exit..." << std::endl;
    std::cin.get();
    return result;
}
